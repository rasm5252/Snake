// Setup
var r = document.querySelector(':root');

let canvas = document.getElementById("canvas");
let c = canvas.getContext("2d");

let canvasWidth;
let canvasHeight;
function resize() {
    canvasWidth = window.innerWidth * 0.7;
    canvasHeight = canvasWidth;
    c.canvas.width  = canvasWidth;
    c.canvas.height = canvasHeight;

    if (canvasHeight > window.innerHeight * 0.85) {
        canvasHeight = window.innerHeight * 0.85;
        canvasWidth = canvasHeight;
        c.canvas.width  = canvasWidth;
        c.canvas.height = canvasHeight;
    }

    r.style.setProperty('--canvasWidth', canvasWidth + "px");

    cellWidth = canvasWidth / cellCountX;
    cellHeight = canvasHeight / cellCountY;
}

let cellCountX = 20;
let cellCountY = 20;
let cellWidth;
let cellHeight;

function Vector2(x, y) {
    this.x = x;
    this.y = y;
}
function roundRect(ctx, x, y, width, height, radius, fill, stroke) {
    if (typeof stroke === 'undefined') {
        stroke = true;
    }
    if (typeof radius === 'undefined') {
        radius = 5;
    }
    if (typeof radius === 'number') {
        radius = {tl: radius, tr: radius, br: radius, bl: radius};
    } else {
        var defaultRadius = {tl: 0, tr: 0, br: 0, bl: 0};
        for (var side in defaultRadius) {
        radius[side] = radius[side] || defaultRadius[side];
        }
    }
    ctx.beginPath();
    ctx.moveTo(x + radius.tl, y);
    ctx.lineTo(x + width - radius.tr, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius.tr);
    ctx.lineTo(x + width, y + height - radius.br);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius.br, y + height);
    ctx.lineTo(x + radius.bl, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius.bl);
    ctx.lineTo(x, y + radius.tl);
    ctx.quadraticCurveTo(x, y, x + radius.tl, y);
    ctx.closePath();
    if (fill) {
        ctx.fill();
    }
    if (stroke) {
        ctx.stroke();
    }
} 
String.prototype.replaceAt = function(index, replacement) {
    return this.substr(0, index) + replacement + this.substr(index + replacement.length);
}
// Input
let input = new Array();
document.addEventListener('keydown', function(event) {
    if (event.keyCode == 32) {
        if (event.stopPropagation) {
            event.stopPropagation();
            event.preventDefault();
        }
        togglePause();
    }

    if (isPaused) {
        return;
    }

    switch (event.keyCode) {
        case 38: // UP
            gameRunning = true;
            if (input[input.length - 1] != 0) {
                input.push(0);
            }
            break;
        case 39: // RIGHT
            gameRunning = true;
            if (input[input.length - 1] != 1) {
                input.push(1);
            }
            break;
        case 40: // DOWN
            gameRunning = true;
            if (input[input.length - 1] != 2) {
                input.push(2);
            }
            break;
        case 37: // LEFT
            gameRunning = true;
            if (input[input.length - 1] != 3) {
                input.push(3);
            }
            break;
    }
});

$(".highscoreName").keyup(function (event) {
    if(event.keyCode == 8) {
        $(this).prev('.highscoreName').focus();
    }
    if (this.value.length == this.maxLength) {
        $(this).blur()
        $(this).next('.highscoreName').focus();
    }

    updateLeaderboardName();
});

// Game Variables
let snake = new Snake();
let currentCells;
let nextCells;

let score = 0;
let gameOver = false;
let gameRunning = false;

function Snake() {
    this.origin = new Vector2(9, 9);
    this.init = function() {
        nextCells[this.origin.x][this.origin.y].state = 3;
        this.bodyIndex.unshift(this.origin);
        this.updateBody();
    }

    this.input = 0;
    this.dir = this.dir = new Vector2(0, 0);
    this.updateDir = function() {
        let targetDir;
        switch (this.input) {
            case 0: // UP
                targetDir = new Vector2(0, -1);
                break;
            case 1: // RIGHT
                targetDir = new Vector2(1, 0);
                break;
            case 2: // DOWN
                targetDir = new Vector2(0, 1);
                break;
            case 3: // LEFT
                targetDir = new Vector2(-1, 0);
                break;
        }
        if (this.input != undefined) {
            if (this.headIndex.x + targetDir.x < cellCountX && this.headIndex.y + targetDir.y < cellCountY &&
                this.headIndex.x + targetDir.x >= 0 && this.headIndex.y + targetDir.y >= 0) {
                if (currentCells[this.headIndex.x + targetDir.x][this.headIndex.y + targetDir.y].state != 1) {
                    this.dir = targetDir;
                }
            }
        }
    }

    this.targetCell;
    this.bodyIndex = new Array();
    this.headIndex;
    this.tailIndex;
    this.updateBody = function() {
        this.headIndex = null;
        this.tailIndex = null;
        this.headIndex = this.bodyIndex[0];
        this.tailIndex = this.bodyIndex[this.bodyIndex.length - 1];
    }
}

function Cell(x, y, state) {
    this.index = new Vector2(x, y);
    this.state = state;

    this.update = function() {
        if (snake.dir.x == 0 && snake.dir.y == 0) {
            return;
        }

        let newHighscore;
        let targetIndex = new Vector2(snake.headIndex.x + snake.dir.x, snake.headIndex.y + snake.dir.y);
        if (targetIndex.x < 0 || targetIndex.x >= cellCountX || targetIndex.y < 0 || targetIndex.y >= cellCountY) {
            if (!gameOver) {
                newHighscore = updateLeaderboardScores(score);
                if (newHighscore) {
                    updateLeaderboardName();
                    document.getElementById("highscoreScore").innerHTML = "Score: " + score;
                    document.getElementById("highscorePopUp").style.animation = "fadeIn 1s forwards";
                    document.getElementsByClassName("highscoreName")[0].focus();
                } else {
                    document.getElementById("gameOverScore").innerHTML = "Score: " + score;
                    document.getElementById("gameOverPopUp").style.animation = "fadeIn 1s forwards";
                    document.getElementsByClassName("highscoreName")[0].focus();
                }
            }
            gameOver = true;
            return;
        }
        if (currentCells[targetIndex.x][targetIndex.y].state == 1) {
            newHighscore = updateLeaderboardScores(score);
            if (newHighscore) {
                updateLeaderboardName();
                document.getElementById("highscoreScore").innerHTML = "Score: " + score;
                document.getElementById("highscorePopUp").style.animation = "fadeIn 1s forwards";
            } else {
                document.getElementById("gameOverScore").innerHTML = "Score: " + score;
                document.getElementById("gameOverPopUp").style.animation = "fadeIn 1s forwards";
            }
            gameOver = true;
            return;
        }

        switch (this.state) {
            case 1: // Snake
                if (this.index.x == snake.tailIndex.x && this.index.y == snake.tailIndex.y) {
                    if (currentCells[targetIndex.x][targetIndex.y].state != 2) {
                        nextCells[this.index.x][this.index.y].state = 0;
                        snake.bodyIndex.pop(this.index);
                    } else {
                        spawnFood();
                        score++;
                        document.getElementById("score").innerHTML = score;
                    }
                }
                break;
            case 3: // Head
                nextCells[targetIndex.x][targetIndex.y].state = 3;
                nextCells[this.index.x][this.index.y].state = 1;
                snake.bodyIndex.unshift(targetIndex);
                break;
        }
    }

    this.draw = function() {
        c.fillStyle = "#000";
        switch (this.state) {
            case 0: // Null
                c.fillStyle = "#e4edec";
                break;
            case 1: // Snake
                c.fillStyle = "#13B89F";   
                break;
            case 2: // Food
                c.fillStyle = "#D42568";
                break;
            case 3: // Head
                c.fillStyle = "#006666";   
                break;
        }
        c.strokeStyle = "#fff";
        c.lineWidth = 2;
        c.beginPath();
        c.rect(this.index.x * cellWidth, this.index.y * cellHeight, cellWidth, cellHeight);
        c.fill();
        c.stroke();
        roundRect(c, this.index.x * cellWidth, this.index.y * cellHeight, cellWidth, cellHeight, 5, false, true);
    }
}

function spawnFood() {
    let freeCells = new Array();
    for (let x = 0; x < currentCells.length; x++) {
        for (let y = 0; y < currentCells[x].length; y++) {
            if (currentCells[x][y].state == 0) {
                freeCells.push(currentCells[x][y]);
            }
        }
    }

    if (freeCells.length != 0) {
        let randomIndex = Math.floor(Math.random() * freeCells.length);
        nextCells[freeCells[randomIndex].index.x][freeCells[randomIndex].index.y].state = 2;
    }
}

function init() {
    cellWidth = canvasWidth / cellCountX;
    cellHeight = canvasHeight / cellCountY;

    currentCells = new Array(cellCountX)
    nextCells = new Array(cellCountX)
    for (let x = 0; x < cellCountX; x++) {
        currentCells[x] = new Array(cellCountY);
        nextCells[x] = new Array(cellCountY);
        for (let y = 0; y < cellCountY; y++) {
            currentCells[x][y] = new Cell(x, y, 0);
            nextCells[x][y] = new Cell(x, y, 0);
        }
    }

    snake.init();
    spawnFood();
}

function update() {
    if (!gameOver && !isPaused) {
        snake.input = input[0];
        snake.updateDir();
        for (let x = 0; x < currentCells.length; x++) {
            for (let y = 0; y < currentCells[x].length; y++) {
                currentCells[x][y].update();
            }
        }
        snake.updateBody();
        input.shift();
    }

    c.clearRect(0, 0, canvasWidth, canvasHeight);
    for (let x = 0; x < nextCells.length; x++) {
        for (let y = 0; y < nextCells[x].length; y++) {
            nextCells[x][y].draw();
            currentCells[x][y].state = nextCells[x][y].state;
        }
    }
}

let animationLoopId;
let animationRate = 6;
function animate() {
    animationLoopId = setTimeout(function() {
        update();
        animate();
    }, 1000/animationRate)
}

let isPaused = false;
function togglePause() {
    if (gameOver || !gameRunning) {
        return;
    }

    let icon = document.getElementById("pauseIcon");

    if (isPaused) {
        isPaused = false;
        icon.src = "Images/PauseIcon.png";
    } else {
        isPaused = true;
        icon.src = "Images/ResumeIcon.png";
    }
}

function restart() {
    c.clearRect(0, 0, canvasWidth, canvasHeight);

    currentCells = new Array(cellCountX)
    nextCells = new Array(cellCountX)
    for (let x = 0; x < cellCountX; x++) {
        currentCells[x] = new Array(cellCountY);
        nextCells[x] = new Array(cellCountY);
        for (let y = 0; y < cellCountY; y++) {
            currentCells[x][y] = new Cell(x, y, 0);
            nextCells[x][y] = new Cell(x, y, 0);
        }
    }

    document.getElementById('gameOverPopUp').style.animation = 'fadeOut 0.5s forwards';
    document.getElementById('highscorePopUp').style.animation = 'fadeOut 0.5s forwards';


    input = new Array();

    for (let i = 0; i < leaderboardPlacards.length; i++) {
        leaderboardPlacards[i].getElementsByTagName("p")[0].style.background = "#e4edec";
    }
    for (let i = 0; i < highScoreNameCharacters.length; i++) {
        highScoreNameCharacters[i].value = "";
    }
    
    score = 0;
    document.getElementById("score").innerHTML = score;

    gameOver = false;
    if (isPaused) {
        togglePause();
    }
    gameRunning = false;

    snake = new Snake();
    snake.init();

    update();
    spawnFood();
}

let gameDifficulty = 1;

function changeDifficulty(difficulty) {
    if (gameRunning) {
        restart();
    }

    gameDifficulty = difficulty;

    let easy = document.getElementById("difficultyEasy");
    let medium = document.getElementById("difficultyMedium");
    let hard = document.getElementById("difficultyHard");

    if (animationLoopId == null) {
        return;
    }

    updateLeaderboardScores(0);

    switch (difficulty) {
        case 0:
            animationRate = 3;
            clearTimeout(animationLoopId);
            animate();
            easy.style.background = "#b2cfcb";
            medium.style.background = "#e4edec";
            hard.style.background = "#e4edec";
            return;
        case 1:
            animationRate = 6;
            clearTimeout(animationLoopId);
            animate();
            easy.style.background = "#e4edec";
            medium.style.background = "#b2cfcb";
            hard.style.background = "#e4edec";
            return;
        case 2:
            animationRate = 9;
            clearTimeout(animationLoopId);
            animate();
            easy.style.background = "#e4edec";
            medium.style.background = "#e4edec";
            hard.style.background = "#b2cfcb";
            return;
    }
}

let newHighscoreIndex = null;
if (localStorage.getItem("highscores") == null) {
    localStorage.setItem("highscores", JSON.stringify(new Array(JSON.stringify(new Array()), 
                                                                JSON.stringify(new Array()), 
                                                                JSON.stringify(new Array()))));
}
let leaderboardPlacards = document.getElementById("leaderboardPlacards").getElementsByTagName("li");
let highScoreNameCharacters = document.getElementsByClassName("highscoreName");
function updateLeaderboardScores(newScore) {
    let isNewHighscore = false;

    let highscores = JSON.parse(localStorage.getItem("highscores"));
    let currentHighscores = JSON.parse(highscores[gameDifficulty]);

    if (currentHighscores.length == 0) {
        currentHighscores = new Array();
        for (let i = 0; i < leaderboardPlacards.length; i++) {
            currentHighscores.unshift(new Vector2("———", 0));
        }
    }
    
    for (let i = 0; i < currentHighscores.length; i++) {
        if (newScore > currentHighscores[i].y) {
            currentHighscores.splice(i, 0, new Vector2("———", score));
            currentHighscores.pop();
            leaderboardPlacards[i].getElementsByTagName("p")[0].style.background = "#b2cfcb";
            isNewHighscore = true;   
            newHighscoreIndex = i;
            i = currentHighscores.length;         
        }
    }
    
    for (let i = 0; i < leaderboardPlacards.length; i++) {
        if (currentHighscores[i].y == 0) {
            leaderboardPlacards[i].childNodes[1].innerHTML = "—";
        } else {
            leaderboardPlacards[i].childNodes[1].innerHTML = currentHighscores[i].y;
        }
        leaderboardPlacards[i].childNodes[0].innerHTML = currentHighscores[i].x;
    }
    
    highscores[gameDifficulty] = JSON.stringify(currentHighscores);
    localStorage.setItem("highscores", JSON.stringify(highscores));

    return isNewHighscore;
}
function updateLeaderboardName() {
    let name = "   ";
    if (highScoreNameCharacters[0].value !== "") {
        name = name.replaceAt(0, highScoreNameCharacters[0].value.toUpperCase());
    }
    if (highScoreNameCharacters[1].value !== "") {
        name = name.replaceAt(1, highScoreNameCharacters[1].value.toUpperCase());
    }
    if (highScoreNameCharacters[2].value !== "") {
        name = name.replaceAt(2, highScoreNameCharacters[2].value.toUpperCase());
    }

    let highscores = JSON.parse(localStorage.getItem("highscores"));
    let currentHighscores = JSON.parse(highscores[gameDifficulty]);

    currentHighscores[newHighscoreIndex].x = name;      
    leaderboardPlacards[newHighscoreIndex].childNodes[0].innerHTML = name;
    
    highscores[gameDifficulty] = JSON.stringify(currentHighscores);
    localStorage.setItem("highscores", JSON.stringify(highscores));
}

resize();
updateLeaderboardScores(0);
init();
update();
animate();
changeDifficulty(gameDifficulty);